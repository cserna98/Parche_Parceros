package com.ParcheParceros.Back;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackParcheApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackParcheApplication.class, args);
	}

}
