package com.ParcheParceros.Back;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackParcheApplicationTests {

	@Test
	void contextLoads() {
	}

}
